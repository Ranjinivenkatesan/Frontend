/* eslint-disable no-unused-vars */
import React from 'react'

const Footer = () => {
    return (
        <div className=' position-absolute bottom-0 bg-dark text-light w-100 d-flex justify-content-center align-items-center ' style={{ height: "5svh" }}>
            <h5>Besant @ 2024</h5>
        </div>
    )
}

export default Footer