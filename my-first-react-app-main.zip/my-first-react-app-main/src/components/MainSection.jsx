import React from 'react'

const MainSection = () => {
    return (
        <div>MainSection</div>
    )
}

export default MainSection